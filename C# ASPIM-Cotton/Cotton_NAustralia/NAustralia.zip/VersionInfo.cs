using System.Reflection;
[assembly: AssemblyFileVersion("7.8.2016.002")]
